package com.sunny.menu;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, nav, page;
    int RED=Color.rgb(255,25,70), BG=Color.rgb(5,5,7), PANEL=Color.rgb(14,14,18);

    GradientDrawable shape(int c,int stroke) {
        GradientDrawable g=new GradientDrawable();
        g.setColor(c); g.setCornerRadius(22); if(stroke>0)g.setStroke(stroke,RED);
        return g;
    }
    TextView text(String s,float z,int c){
        TextView v=new TextView(this); v.setText(s);v.setTextSize(z);v.setTextColor(c);
        v.setPadding(14,8,14,8);return v;
    }
    @Override public void onCreate(Bundle b){super.onCreate(b);build();}

    void build(){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(12,12,12,12);root.setBackgroundColor(BG);

        LinearLayout header=new LinearLayout(this);
        TextView t=text("SUNNY MENU V2",13,Color.WHITE);
        header.addView(t,new LinearLayout.LayoutParams(0,52,1));
        TextView status=text("● ONLINE",11,RED);header.addView(status,new LinearLayout.LayoutParams(90,52));
        root.addView(header);

        LinearLayout body=new LinearLayout(this);body.setBackground(shape(PANEL,1));
        nav=new LinearLayout(this);nav.setOrientation(LinearLayout.VERTICAL);nav.setPadding(5,10,5,10);
        body.addView(nav,new LinearLayout.LayoutParams(68,-1));

        page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);page.setPadding(8,12,12,12);
        ScrollView scroll=new ScrollView(this);scroll.addView(page);
        body.addView(scroll,new LinearLayout.LayoutParams(0,-1,1));
        root.addView(body,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);

        addNav("PLAYER","♟"); addNav("COMBAT","✦"); addNav("VISUAL","◈");
        addNav("WORLD","◎"); addNav("SYSTEM","⚙");
        show("PLAYER");
        addOverlayButton();
    }

    void addOverlayButton(){
        TextView info=text("Nút nổi: bật để hiện menu trên màn hình sau khi thoát app.",11,Color.LTGRAY);
        root.addView(info,new LinearLayout.LayoutParams(-1,48));
        Button b=new Button(this); b.setText("BẬT MENU NỔI");
        b.setTextColor(Color.WHITE); b.setBackground(shape(RED,0));
        b.setOnClickListener(v->{
            if(Build.VERSION.SDK_INT>=23 && !Settings.canDrawOverlays(this)){
                Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())); startActivity(i);
                Toast.makeText(this,"Hãy cấp quyền Hiển thị trên ứng dụng khác, rồi bấm lại.",Toast.LENGTH_LONG).show();
            } else { startFloating(); Toast.makeText(this,"Menu nổi đã bật. Bạn có thể thoát app.",Toast.LENGTH_SHORT).show(); }
        });
        root.addView(b,new LinearLayout.LayoutParams(-1,52));
    }

    void startFloating(){
        Intent i=new Intent(this,FloatingService.class);
        if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i);
    }

    void addNav(final String name,String icon){
        TextView v=text(icon,24,Color.WHITE);v.setGravity(Gravity.CENTER);
        v.setOnClickListener(x->show(name));
        nav.addView(v,new LinearLayout.LayoutParams(-1,58));
    }

    void show(String cat){
        page.removeAllViews();
        TextView h=text(cat,14,RED);page.addView(h,new LinearLayout.LayoutParams(-1,48));
        String[] a;
        if(cat.equals("PLAYER")) a=new String[]{"God Mode","Infinite Health","Infinite Armor","Infinite Ammo","Movement Speed","Jump Power"};
        else if(cat.equals("COMBAT")) a=new String[]{"Damage Multiplier","Recoil Control","Fire Rate","Aim FOV","Crosshair","Weapon Range"};
        else if(cat.equals("VISUAL")) a=new String[]{"Player Outline","Name","Health Bar","Distance","Box","Skeleton Debug"};
        else if(cat.equals("WORLD")) a=new String[]{"Teleport Coordinates","Gravity","Time Scale","Spawn NPC","Weather","World Speed"};
        else a=new String[]{"FPS Counter","RAM Monitor","Ping Monitor","Save Config","Load Config","Reset Config"};
        for(String s:a) addControl(s);
    }

    void addControl(String label){
        LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);
        TextView n=text(label,12,Color.WHITE);row.addView(n,new LinearLayout.LayoutParams(0,58,1));

        Switch sw=new Switch(this);
        sw.setOnCheckedChangeListener((b,on)->GameBridge.set(label,on));
        row.addView(sw,new LinearLayout.LayoutParams(64,58));

        View line=new View(this);line.setBackgroundColor(Color.rgb(70,18,30));
        page.addView(row,new LinearLayout.LayoutParams(-1,58));
        page.addView(line,new LinearLayout.LayoutParams(-1,1));
    }

    // Adapter point for the user's own game.
    // Replace these calls with the game's official/debug API.
    static class GameBridge {
        static final Map<String,Boolean> state=new HashMap<>();
        static void set(String feature,boolean enabled){state.put(feature,enabled);}
        static boolean get(String feature){return Boolean.TRUE.equals(state.get(feature));}
    }
}
