package com.sunny.menu;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.util.*;

public class FloatingService extends Service {
    private WindowManager wm;
    private View bubble, panel;
    private boolean opened=false;
    private final int RED=Color.rgb(255,25,70), BG=Color.rgb(5,5,7), PANEL=Color.rgb(14,14,18);
    private final String[] cats={"PLAYER","COMBAT","VISUAL","WORLD","SYSTEM"};

    @Override public void onCreate(){ super.onCreate(); createChannel(); startForeground(1001, notification()); wm=(WindowManager)getSystemService(WINDOW_SERVICE); showBubble(); }
    private void createChannel(){ if(Build.VERSION.SDK_INT>=26){ NotificationChannel c=new NotificationChannel("sunny_overlay","Sunny Menu",NotificationManager.IMPORTANCE_LOW); c.setDescription("Sunny floating menu"); ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c); } }
    private Notification notification(){
        Intent i=new Intent(this,MainActivity.class); PendingIntent pi=PendingIntent.getActivity(this,0,i,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,"sunny_overlay"):new Notification.Builder(this);
        return b.setContentTitle("Sunny Menu V2").setContentText("Menu nổi đang hoạt động").setSmallIcon(android.R.drawable.ic_dialog_info).setContentIntent(pi).setOngoing(true).build();
    }
    private WindowManager.LayoutParams lp(int w,int h,int gravity){
        int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
        return new WindowManager.LayoutParams(w,h,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);
    }
    private GradientDrawable bg(int c,float r){ GradientDrawable g=new GradientDrawable(); g.setColor(c); g.setCornerRadius(r); return g; }
    private TextView tv(String s,float size,int color){ TextView t=new TextView(this); t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER_VERTICAL);t.setPadding(14,8,14,8); return t; }
    private void showBubble(){
        if(bubble!=null)return;
        TextView b=tv("☰",24,Color.WHITE); b.setGravity(Gravity.CENTER); b.setBackground(bg(RED,80));
        final WindowManager.LayoutParams p=lp(62,62,Gravity.TOP|Gravity.START);p.x=24;p.y=180;
        b.setOnTouchListener(new View.OnTouchListener(){float sx,sy;int ox,oy;boolean moved;
            public boolean onTouch(View v,android.view.MotionEvent e){switch(e.getAction()){case MotionEvent.ACTION_DOWN:sx=e.getRawX();sy=e.getRawY();ox=p.x;oy=p.y;moved=false;return true;case MotionEvent.ACTION_MOVE:int dx=(int)(e.getRawX()-sx),dy=(int)(e.getRawY()-sy);if(Math.abs(dx)+Math.abs(dy)>10)moved=true;p.x=ox+dx;p.y=oy+dy;wm.updateViewLayout(b,p);return true;case MotionEvent.ACTION_UP:if(!moved)togglePanel();return true;}return true;}});
        bubble=b;wm.addView(bubble,p);
    }
    private void togglePanel(){ if(opened){closePanel();return;} showPanel("PLAYER"); }
    private void showPanel(String cat){
        if(panel!=null)wm.removeView(panel);
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(10,10,10,10);box.setBackground(bg(BG,28));
        LinearLayout head=new LinearLayout(this); head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title=tv("SUNNY MENU V2",15,Color.WHITE);head.addView(title,new LinearLayout.LayoutParams(0,48,1));
        TextView close=tv("×",28,Color.WHITE);close.setGravity(Gravity.CENTER);head.addView(close,new LinearLayout.LayoutParams(48,48));close.setOnClickListener(v->closePanel());box.addView(head);
        HorizontalScrollView hs=new HorizontalScrollView(this); LinearLayout tabs=new LinearLayout(this); for(String c:cats){TextView t=tv(c,10,c.equals(cat)?RED:Color.WHITE);t.setGravity(Gravity.CENTER);tabs.addView(t,new LinearLayout.LayoutParams(82,42));t.setOnClickListener(v->showPanel(c));}hs.addView(tabs);box.addView(hs);
        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);
        String[] a=features(cat); for(String s:a){ LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);TextView n=tv(s,11,Color.WHITE);row.addView(n,new LinearLayout.LayoutParams(0,50,1));Switch sw=new Switch(this);sw.setChecked(MainActivity.GameBridge.get(s));sw.setOnCheckedChangeListener((v,on)->MainActivity.GameBridge.set(s,on));row.addView(sw,new LinearLayout.LayoutParams(60,50));list.addView(row); }
        ScrollView sv=new ScrollView(this);sv.addView(list);box.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        panel=box;WindowManager.LayoutParams p=lp(330,470,Gravity.TOP|Gravity.START);p.x=80;p.y=130;p.flags=WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;wm.addView(panel,p);opened=true;
    }
    private String[] features(String c){
        if(c.equals("PLAYER"))return new String[]{"God Mode","Infinite Health","Infinite Armor","Infinite Ammo","Movement Speed","Jump Power"};
        if(c.equals("COMBAT"))return new String[]{"Damage Multiplier","Recoil Control","Fire Rate","Aim FOV","Crosshair","Weapon Range"};
        if(c.equals("VISUAL"))return new String[]{"Player Outline","Name","Health Bar","Distance","Box","Skeleton Debug"};
        if(c.equals("WORLD"))return new String[]{"Teleport Coordinates","Gravity","Time Scale","Spawn NPC","Weather","World Speed"};
        return new String[]{"FPS Counter","RAM Monitor","Ping Monitor","Save Config","Load Config","Reset Config"};
    }
    private void closePanel(){ if(panel!=null){wm.removeView(panel);panel=null;}opened=false; }
    @Override public int onStartCommand(Intent i,int flags,int id){return START_STICKY;}
    @Override public void onDestroy(){closePanel();if(bubble!=null){wm.removeView(bubble);bubble=null;}super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}
}
