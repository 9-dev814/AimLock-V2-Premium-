SUNNY MENU V2 - GITHUB BUILD

1. Upload the contents of this ZIP to the root of your GitHub repository.
2. Make sure .github/workflows/main.yml is present.
3. Open Actions -> Build SunnyMenu APK -> Run workflow.
4. When the run finishes successfully, open the run and download artifact:
   SunnyMenuV2-APK

The artifact contains app-debug.apk.

The overlay is an Android floating menu for the app itself. It requires the
user to grant "Display over other apps" permission. It does not inject or
modify third-party games.
